Program Absensi dan Informasi Siswa berbasis web menggunakan PHP, SQL, dan Bootstrap
